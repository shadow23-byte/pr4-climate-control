namespace ClimateControlMetrics;

public sealed class LegacyReadingChecker(ClimateRules rules)
{
    // Учебная исходная версия: глубокая вложенность скрывает основной путь.
    public CheckResult Check(ClimateSample sample, long now)
    {
        if (ClimateRules.IsKnownSensor(sample.SensorId))
        {
            if (ClimateRules.IsCurrent(sample.TimestampUnixSeconds, now))
            {
                if (ClimateRules.IsPlausibleTemperature(sample.TemperatureMilliCelsius))
                {
                    if (rules.HasValidSignature(sample))
                    {
                        return CheckResult.Accepted;
                    }
                    else
                    {
                        return CheckResult.InvalidSignature;
                    }
                }
                else
                {
                    return CheckResult.OutOfRange;
                }
            }
            else
            {
                return CheckResult.Expired;
            }
        }
        else
        {
            return CheckResult.UnknownSensor;
        }
    }
}
