namespace ClimateControlMetrics;

public sealed class RefactoredReadingChecker(ClimateRules rules)
{
    // Каждое отклонение завершается сразу; основной путь остаётся видимым.
    public CheckResult Check(ClimateSample sample, long now)
    {
        if (!ClimateRules.IsKnownSensor(sample.SensorId))
            return CheckResult.UnknownSensor;

        if (!ClimateRules.IsCurrent(sample.TimestampUnixSeconds, now))
            return CheckResult.Expired;

        if (!ClimateRules.IsPlausibleTemperature(sample.TemperatureMilliCelsius))
            return CheckResult.OutOfRange;

        if (!rules.HasValidSignature(sample))
            return CheckResult.InvalidSignature;

        return CheckResult.Accepted;
    }
}
