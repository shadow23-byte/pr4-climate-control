using System.Globalization;
using System.Security.Cryptography;
using System.Text;

namespace ClimateControlMetrics;

public sealed class ClimateRules(byte[] key)
{
    private readonly byte[] _key = (byte[])key.Clone();

    public byte[] Sign(ClimateSample sample)
    {
        string message = string.Join("|", sample.SensorId,
            sample.TemperatureMilliCelsius.ToString(CultureInfo.InvariantCulture),
            sample.TimestampUnixSeconds.ToString(CultureInfo.InvariantCulture));
        return HMACSHA256.HashData(_key, Encoding.UTF8.GetBytes(message));
    }

    public bool HasValidSignature(ClimateSample sample) =>
        sample.Signature.Length == 32 &&
        CryptographicOperations.FixedTimeEquals(Sign(sample), sample.Signature);

    public static bool IsKnownSensor(string sensorId) => sensorId is "room-101" or "room-202";

    public static bool IsCurrent(long timestamp, long now) =>
        timestamp >= now - 300 && timestamp <= now + 30;

    public static bool IsPlausibleTemperature(int value) => value is >= -40_000 and <= 85_000;
}
