namespace ClimateControlMetrics;

public sealed record ClimateSample(
    string SensorId,
    int TemperatureMilliCelsius,
    long TimestampUnixSeconds,
    byte[] Signature);

public enum CheckResult
{
    Accepted,
    UnknownSensor,
    Expired,
    OutOfRange,
    InvalidSignature
}
