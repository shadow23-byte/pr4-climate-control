using System.Text;
using ClimateControlMetrics;

const long now = 1_800_000_000;
var rules = new ClimateRules(Encoding.UTF8.GetBytes("pr4-demo-key-for-classroom-only"));
var oldChecker = new LegacyReadingChecker(rules);
var newChecker = new RefactoredReadingChecker(rules);
var valid = new ClimateSample("room-101", 22_500, now, []);
valid = valid with { Signature = rules.Sign(valid) };

var cases = new (string Name, ClimateSample Sample, CheckResult Expected)[]
{
    ("Подлинное показание", valid, CheckResult.Accepted),
    ("Неизвестный датчик", valid with { SensorId = "room-999" }, CheckResult.UnknownSensor),
    ("Устаревшее время", valid with { TimestampUnixSeconds = now - 301 }, CheckResult.Expired),
    ("Будущее время", valid with { TimestampUnixSeconds = now + 31 }, CheckResult.Expired),
    ("Недопустимая температура", valid with { TemperatureMilliCelsius = 90_000 }, CheckResult.OutOfRange),
    ("Подменённая температура", valid with { TemperatureMilliCelsius = 23_000 }, CheckResult.InvalidSignature),
    ("Подпись отсутствует", valid with { Signature = [] }, CheckResult.InvalidSignature)
};

int passed = 0;
foreach (var (name, sample, expected) in cases)
{
    CheckResult before = oldChecker.Check(sample, now);
    CheckResult after = newChecker.Check(sample, now);
    bool ok = before == expected && after == expected;
    Console.WriteLine($"{(ok ? "PASS" : "FAIL")} | {name} | до: {before}; после: {after}");
    if (ok) passed++;
}
Console.WriteLine($"Итог: {passed}/{cases.Length}; расхождений: {cases.Length - passed}");
Environment.ExitCode = passed == cases.Length ? 0 : 1;
